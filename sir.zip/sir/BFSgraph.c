// Program 8.4 : BFS of Graph

#include<stdio.h>

typedef struct 
{
 	int data[20];
	int front, rear;
}QUEUE;

void add(QUEUE *pq, int n)
{
	pq->rear++;
 	pq->data[pq->rear]=n;
}
int del(QUEUE *pq)
{
 	pq->front++;
 	return pq->data[pq->front];
}
void initq(QUEUE *pq)
{
 	pq->front= pq->rear=-1;
}
int isempty(QUEUE *pq)
{
 	return (pq->rear== pq->front);
}
int main()
{
 	int m[10][10] = {0}, n , i, j;
 	void bfs(int m[10][10], int n);
	printf("\nHow many vertices :");
 	scanf("%d",&n);
 	for(i=0;i<n;i++)
  	for(j=0;j<n;j++)
  	{
   		if(i!=j)
   		{
     			printf("Is there an edge between vertex %d and %d (1/0)",i+1,j+1);
     			scanf("%d",&m[i][j]);
   		}
 	}
	bfs(m,n);
}
void bfs(int m[10][10], int n)
{ 
	int i,j,v,w ;
  	int visited[20] = {0};
  	QUEUE q;
  	initq(&q);
  	printf("\nThe Breadth first traversal is :\n");
  	v=0;
  	visited[v]=1;
  	add(&q,v);
 	while(!isempty(&q))
  	{
    		v=del(&q);
    		printf(" v%d ",v+1);
    		for(w=0;w<n;w++)
    		{
    			if( (m[v][w]==1)&&(visited[w]==0))
			{  
          			add(&q,w);
	    	   		visited[w]=1;
	 	  	}
  		}
	}
}



