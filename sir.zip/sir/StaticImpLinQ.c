// Program 6.1 : Static Implementation of Linear Queue

#include<stdio.h>
#define MAX 100
typedef struct
{ 
	int data[MAX];
	int front , rear;
}	QUEUE;
/*********************FUNCTIONS ********************/
void initqueue(QUEUE *pq)
{ 
	pq->front = pq->rear = -1;
}
void addq(QUEUE *pq, int num)
{
	pq->rear++;
   	pq->data[pq->rear] = num;
}
int delq(QUEUE *pq)
{
	int num;
   	pq->front++;
   	num=pq->data[pq->front];
   	return(num);
}
int isempty(QUEUE *pq)
{
	return(pq->front == pq->rear);
}
int isfull(QUEUE *pq)
{
  	return(pq->rear==MAX-1);
}
int main()
{ 
	int n,choice;
  	QUEUE  q1;

 	initqueue(&q1);
  	do
   	{
   		printf("\n1:ADD\n2:DELETE\n3:EXIT");
   		printf("\n\nEnter your choice :");
   		scanf("%d",&choice);
   		switch(choice)
   		{
    			case 1 : /* ADD */
		 		printf("\nEnter the element to be added :");
		 		scanf("%d",&n);
				if (isfull(&q1))
            				printf("Queue Overflow");
       				else
 					addq(&q1,n);
		 	break;	
     			case 2 : /* DELETE */
				if(isempty(&q1)==1)
					printf("\nQueue is empty \n");
				else
		  			printf("\n The deleted element is %d \n",delq(&q1));
	  		break;
 		}
  	} while(choice !=3);
  
}

