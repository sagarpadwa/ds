// Program 8.4 : Shortest Path Algorithm

#include <stdio.h>
#define MAX 20

void shortest(int C[10][10], int n)
{
	int i,j,u,v,w,min, count;
  	int visited[10]={0};
  	int dist[10];

  	printf("Enter the source vertex :");
  	scanf("%d",&v);
  	v = v-1;
  	/* initialize dist array  */
  	for(i=0;i<n;i++)
     		dist[i]=C[v][i];
  		visited[v]=1;
  		count = 1;
 
 	while (count < n)
 	{
		min = 999;
		for(i=0;i<n;i++)
	  		if((visited[i]==0)&&(dist[i]<min))
	   			{   
					min = dist[i]; 
					u = i; 
				}
		count++;
		visited[u]=1;
		for (w = 0;w<n;w++)
		{
    			if (! visited[w])
  				if (dist[u] + C[u][w]<dist[w])
					dist[w] = dist[u]+C[u][w];
		}
  	}
  	printf("The shortest paths are :\n");

	for(i=0;i<n;i++)
      		printf("From v%d to v%d = %d\n", v+1, i+1, dist[i]);
}

int main()
{
	int C[10][10]= {0}, n , i, j;
	printf("\nHow many vertices :");
	scanf("%d",&n);
	printf("Enter the Adjacency cost matrix:999 if there is no edge");
	for(i=0;i<n;i++)
	for(j=0;j<n;j++)
	{
    		if(i<j)
	 	{ 
	    		printf("\n Enter cost of edge %d -> %d ",i+1,j+1);
       			scanf("%d",&C[i][j]);
    	 		C[j][i] = C[i][j];
	 	}
	}
	shortest(C,n);
}



