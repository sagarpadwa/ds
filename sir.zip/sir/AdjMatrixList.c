// Program 8.2 : Adjacency Matrix to List


#include<stdio.h>
#include<malloc.h>

struct node
{
	int vertex;
	struct node *next;
} *list[10];

void createmat(int m[10][10], int n)
{
 	int i,j;
 	char ans;
 	for(i=0;i<n;i++)	
 	for(j=0;j<n;j++)
 	{
  		m[i][i]=0;
  		if(i!=j)
  		{
    			printf("\nIs there an edge between %d and %d (1/0) : ", i+1,j+1);
    			scanf("%d",&m[i][j]);
   		}
  	}

}
void dispmat(int m[10][10], int n)
{
 	int i,j;
 	printf("\nThe adjacency matrix is :\n");
 	for(i=0;i<n;i++)
 	{
 		for(j=0;j<n;j++)
    			printf("%5d",m[i][j]);
 			printf("\n");
  	}
}
void createlist(int m[10][10], int n)
{
 	int i, j;
 	struct node *temp, *newnode;
 	for(i=0; i<n;i++)	
 	{
  		list[i]=NULL;
  		for(j=0;j<n;j++)
  		{
   			if (m[i][j]==1)
   			{
    				newnode=(struct node *)malloc(sizeof(struct node));
    				newnode->next=NULL;
    				newnode->vertex=j+1;
    				if(list[i]==NULL)
      					list[i]=temp=newnode;
    				else
    				{
	     				temp->next=newnode;
   	  				temp=newnode;
    				}
   			}
 		}
	}
}
void displist(int n)
{
 	struct node *temp;
 	int i;
 	printf("\nThe adjacency list is :\n");
	for(i=0;i<n;i++)
 	{
  		printf("\nv%d->",i+1);
  		temp=list[i];
  		while(temp)
  		{
   			printf("v%d -> ",temp->vertex);
   			temp=temp->next;
 		}
  		printf("NULL");
 	}
}
int main()
{
 	int m[10][10], n;
 	printf("\nEnter the number of vertices :");
 	scanf("%d",&n);
 	createmat(m,n);
 	dispmat(m,n);
 	createlist(m,n);
 	displist(n);
}
