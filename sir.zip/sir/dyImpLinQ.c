// Program 6.2 :  Dynamic Implementation of Linear Queue 

#include <stdio.h>
#include <malloc.h>
typedef struct node
{
 	int info;
 	struct node *next;
}NODE;

NODE *front, *rear;

void initqueue()
{
	front=rear=NULL;
}
int isempty()
{
	return(front==NULL);
}
int delq()
{
	int num;
	NODE *temp=front;
  	num = front->info;
	front=front->next;
	free(temp);
	if(front==NULL)
		rear=NULL;
	return(num);
}
void addq(int num)
{
	NODE * newnode;
	newnode=(NODE * )malloc(sizeof(NODE));
  	newnode->info=num;
  	newnode->next = NULL;
  	if(front == NULL)
  		rear=front=newnode;
  	else
  	{
  		rear->next=newnode;
    		rear=newnode;
  	}
}
int main()
{
	int c,num,n;
	initqueue();
  	do
  	{
		printf("\n\n1 : Add\n2 : Delete\n3 : Exit");
   		printf("\n\nenter your choice :");
   		scanf("%d",&c);
   		switch(c)
   		{
    			case 1 : printf("Enter the element :");
	    		scanf("%d",&num);
  		  		addq(num);
    			break;
   			case 2 :
				if(isempty())
					printf("\nEmpty");
				else
					printf("\nThe  deleted element is %d",delq());
    			break;
    			case 3 : exit(1);
    		}
  }while(c!=3);
}



