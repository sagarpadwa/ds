// Program 6.3 : Circular Queue using Array

#include<stdio.h>
#define MAX 100
typedef struct 
{ 
	int data[MAX];
	int front,rear;
}QUEUE;
/*********************FUNCTIONS ********************/
void initqueue(QUEUE *pq)
{ 
	pq->front = pq->rear = MAX-1;
}
int isempty(QUEUE *pq)
{
  	return(pq->front == pq->rear);
}
int isfull(QUEUE *pq)
{
	return((pq->rear+1)%MAX==pq->front);
}
void addq(QUEUE *pq, int ch1)
{
	pq->rear= (pq->rear+1) % MAX;
	pq->data[pq->rear] = ch1;
}
int delq(QUEUE *pq)
{
  	pq->front=(pq->front+1)%MAX;
    	return pq->data[pq->front];
}
int main()
{ 
	int n,choice;
  	QUEUE q1;
  	initqueue(&q1);
  	do
  	{
		printf("\n1:ADD\n2:DELETE\n3:EXIT");
   		printf("\n\nEnter your choice :");
   		scanf("%d",&choice);
   		switch(choice)
   		{
    			case 1 : /* ADD */
		 		printf("\nEnter the element to be added :");
		 		scanf("%d",&n);
		 		if(isfull(&q1))
					printf("Queue overflow ");
				else
					addq(&q1,n);
		 		break;
     			case 2 : /* DELETE */
				if(isempty(&q1))
		  			printf("\nQueue is empty \n");
				else
		  			printf("The deleted element is %d",delq(&q1));
			break;
     		}
  	}while(choice !=3);
}



