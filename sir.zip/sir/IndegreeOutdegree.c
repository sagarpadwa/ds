// Program 8.1: Indegree and Outdegree

#include<stdio.h>
int main()
{
 	int m[10][10],r,c,sumin,sumout,n,v,i;
 
 	printf("How many vertices :");	
 	scanf("%d",&n);
 	for(r=0;r<n;r++)
  	for(c=0;c<n;c++)
  	{  
		m[r][c]=0;
    		if (r!=c)
    		{
     			printf("Is there an edge between vertex %d and %d (1/0):", r+1,c+1);
     			scanf("%d",&m[r][c]);
    		}
 	}
  	printf("\n\nVertex	\tIndegree\tOutdegree\tTotal degree\n");
  	for(v=0;v<n;v++)
  	{
  		sumin= sumout=0;
  		for(i=0;i<n;i++)
    		{
        		sumin = sumin+ m[i][v];  //sum of column v
  		   	sumout = sumout+ m[v][i]; //sum of row v
     		}
	   	printf("%d\t%d\t%d\t%d\n",v+1, sumin, sumout,sumin+sumout);
  	}
}


