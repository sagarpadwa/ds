// program- radix sort

#include<stdio.h>
int getmax(int arr[],int n)
{
int i,max=arr[0];
for(i=0;i<n;i++)
if(arr[i]> max)
max=arr[i];
return max;
}
void accept(int arr[],int n)
{
for(int i=0;i<n;i++)
scanf("%d",&arr[i]);
}
void display(int arr[],int n)
{
for(int i=0;i<n;i++)
printf("%d\t",arr[i]);
}
// counting sort of arr[] according to the digit represented by place
void counting_sort(int arr[],int n,int place)
{
int output[20],i,count[10]={0};
// calculate occurences in count[]
for(i=0;i<n;i++)
count[(arr[i]/place)%10]++;
// calculate actual position in count[i]
for(i=1;i<10;i++)
count[i]+=count[i-1];
// build the output array
for(i=n-1;i>=0;i--)
{
output[count[(arr[i]/place)%10]-1]=arr[i];
count[(arr[i]/place)%10]--;
}
// copy the output array to arr[]
for( i=0;i<n;i++)
arr[i]=output[i];
}
void radixsort(int arr[],int n )
{
// find the maximum number to know number of digits
int m=getmax( arr, n);
// call counting sort for every digit place to 10^I
// where i is the current digit number
for(int place=1,pass=1;m/place>0;place *=10,pass++)
{
counting_sort(arr,n,place);
printf("\n after pass %d :",pass);
display(arr,n);
}
}
int main()
{
int arr[20],n;
printf("how many elements :");
scanf("%d",&n);
printf("enter the elements :");
accept(arr,n);
radixsort(arr,n);
printf("\n sorted output :");
display(arr,n);
return 0;
}
