// Program 8.3 : DFS of Graph 

#include <stdio.h>
#define MAX 20
typedef struct 
{ 
	int data[MAX];
	int  top;
}STACK;

void initstack(STACK *ps)
{ 	
	ps->top = -1;
}

void push(STACK *ps, int num)
{
 	ps->top++;
  	ps->data[ps->top] = num;
}
int pop(STACK *ps)
{
	return(ps->data[ps->top--]);
}
int isempty(STACK *ps)
{
	return(ps->top == -1);
}
int isfull(STACK *ps)
{
	return(ps->top==MAX-1);
}

void dfs(int m[10][10], int n)
{ 
	int i,v,w,found ;
	int visited[20]={0};
   	STACK  s;
  	initstack(&s);
  	v=0; /* starting vertex */
  	visited[v]=1;
  	push(&s,v);
  	printf(" v%d ",v+1);
  	while(1)
  	{
     		found = 0;
		for(w=0;w<n;w++)
    		{
       			if( (m[v][w]==1)&&(visited[w]==0))
			{ 
		   		push(&s,w);
		   		printf(" v%d  ",w+1);
		   		visited[w]=1;
          			v = w;  
				found = 1;
          			break;
			}
      		}
	  	if(found == 0) //did not find an adjacent unvisited vertex
     			if(isempty(&s))
			break;
 	  	else
			v=pop(&s);
 	}
}

void recdfs(int m[10][10], int n,int v)
{ 
	int w ;
	static int visited[20]={0};
  	visited[v]=1;
  	printf(" v%d ",v+1);
  	for(w=0;w<n;w++)
  	{
  		if( (m[v][w]==1)&&(visited[w]==0))
		{ 
		   recdfs(m,n,w);
		}
  	}
}
int main()
{
 	int m[10][10], n , i, j;
 	printf("\nHow many vertices :");

	scanf("%d",&n);
	for(i=0;i<n;i++)
  		for(j=0;j<n;j++)
  		{
  	 		if(i!=j)
   			{
     				printf("Is there an edge between vertex %d and %d (1/0)",i+1, 						j+1);
     				scanf("%d",&m[i][j]);
   			}		
 		}
 		printf("\nThe Non Recursive Depth First Search is :");
 		dfs(m,n);
 		printf("\nThe Recursive Depth First Search is :");
 		recdfs(m,n,0);
 
}



