#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 100

struct Queue {
    int items[MAX_SIZE];
    int front, rear;
};

void initQueue(struct Queue* queue) {
    queue->front = -1;
    queue->rear = -1;
}

int isEmpty(struct Queue* queue) {
    return (queue->front == -1) || (queue->front > queue->rear);
}

int isFull(struct Queue* queue) {
    return queue->rear == MAX_SIZE - 1;
}

void enqueue(struct Queue* queue, int value) {
    if (isFull(queue)) {
        printf("Queue overflow\n");
        exit(EXIT_FAILURE);
    }

    if (isEmpty(queue)) {
        queue->front = 0;
    }

    queue->items[++queue->rear] = value;
}

int dequeue(struct Queue* queue) {
    if (isEmpty(queue)) {
        printf("Queue underflow\n");
        exit(EXIT_FAILURE);
    }

    int value = queue->items[queue->front++];
    return value;
}

void reverseQueue(struct Queue* queue) {
    if (isEmpty(queue)) {
        return;
    }

    int data = dequeue(queue);
    reverseQueue(queue);
    enqueue(queue, data);
}

void printQueue(struct Queue* queue) {
    if (isEmpty(queue)) {
        printf("Queue is empty\n");
        return;
    }

    printf("Queue: ");
    for (int i = queue->front; i <= queue->rear; ++i) {
        printf("%d ", queue->items[i]);
    }
    printf("\n");
}

int main() {
    struct Queue myQueue;
    initQueue(&myQueue);

    enqueue(&myQueue, 1);
    enqueue(&myQueue, 2);
    enqueue(&myQueue, 3);
    enqueue(&myQueue, 4);
    enqueue(&myQueue, 5);

    printf("Original ");
    printQueue(&myQueue);

    reverseQueue(&myQueue);

    printf("Reversed ");
    printQueue(&myQueue);

    return 0;
}
