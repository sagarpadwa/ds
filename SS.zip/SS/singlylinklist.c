//Program 4.1 : Menu driven Operations on Singly Linked List

#include<stdio.h>
#include<malloc.h>

typedef struct node
{
	int info;
	struct node *next;
}NODE ;

NODE * createlist(NODE * list)
{
	NODE * newnode,*temp;
	int i,n;
	printf("\nHow many elements :");
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		newnode=(NODE *)malloc(sizeof(struct node));
		newnode->next=NULL;
		printf("\nEnter the element");
		scanf("%d",&newnode->info);
		if(list==NULL)
			list=temp=newnode;
		else
		{
			temp->next=newnode;
			temp=newnode;
		}
	}
	return list;
}
NODE * insert(NODE * list, int num, int pos)
  {
	NODE * newnode,*temp;
	int i;
	newnode=(NODE *)malloc(sizeof(struct node));
	newnode->next=NULL;
	newnode->info=num;
	if(pos==1)
	{
		newnode->next=list;
		list=newnode;
		return list; 	
	}
	/** move temp to the node at pos - 1 */
	for(i=1,temp=list;i<=pos-2 && temp!=NULL; i++)
		temp=temp->next;
	if(temp==NULL)
	{
	   printf("Position out of range");
	   return list;
	}
	newnode->next=temp->next;
	temp->next=newnode;
	return list;
}
void display(NODE * list)
{
   NODE * temp;
   for(temp=list;temp!=NULL;temp=temp->next)
   printf("%d\t", temp->info);
}
NODE * delpos(NODE * list, int pos)
{
	NODE * temp = list,*temp1;
	int i;
	if(pos==1)
	{
	list=list->next;
	free(temp);
	return list;
	}
	for(i=1,temp=list;i<pos-1 && temp!=NULL; i++)
	     temp=temp->next;
	if(temp==NULL)
	{
		printf("\nPosition out of range");
		return list;
	}
	temp1=temp->next;
	temp->next=temp1->next;
	free(temp1);
	return list;
}
NODE * delval(NODE * list, int num)
{
	NODE * temp=list,*temp1;
   	if(list->info==num) /* first node */
   	{
		list=list->next;
		free(temp);
		return list;
   	}
	for(temp=list;temp->next!=NULL;temp=temp->next )
   		if(temp->next->info == num)
		{
			temp1=temp->next;
     			temp->next=temp1->next;
     			free(temp1);
     			return list;
		}
   	printf("\nElement not found");
   	return list;
}
NODE * search(NODE * list,int num)
{
	NODE * temp;
	for(temp=list;temp!=NULL;temp=temp->next)
		if(temp->info==num)
			return temp;
	return NULL;
}
int main()
{
	NODE * list=NULL, *temp;
	int choice,n,pos;
	do
	{
		printf("\n1: CREATE");
		printf("\n2: INSERT");
		printf("\n3: DELETE BY NUMBER");
		printf("\n4: DELETE BY POSITION");
		printf("\n5: SEARCH");
		printf("\n6: DISPLAY");
		printf("\n7: EXIT");
		printf("\nEnter your choice :");
		scanf("%d",&choice);
		switch(choice)
		{
			case 1 :
				list=createlist(list);   	
			break;
    			case 2:
				printf("\nEnter the element and position :");
				scanf("%d%d",&n,&pos);
				list=insert(list,n,pos);
				display(list);
			break;
			case 3 :
				printf("\nEnter the element :");
				scanf("%d",&n);
				list=delval(list,n);
				display(list);
			break;
			case 4:
				printf("\nEnter the position :");
				scanf("%d",&pos);
				list=delpos(list,pos);
				display(list);
			break;
	 		case 5:
		 		printf("\nEnter the element to be searched :");
				scanf("%d",&n);
				temp=search(list,n);
				if(temp==NULL)
					printf("\nElement not found");
				else
					printf("\nElement found at node address %u",temp);
			break;
  			case 6: 
				display(list);
			break;
		}/* end switch */
  	}while(choice !=7);
 
}



