//  Program 5.5 : Evaluating a postfix expression 

#include <stdio.h>
#include <ctype.h>
#define MAX 20
typedef struct 
{ 
	int data[MAX];
	int  top;
}STACK;

void initstack(STACK *ps)
{ 
	ps->top = -1;
}

void push(STACK *ps, int num)
{
	ps->top++;
	ps->data[ps->top] = num; 	
}
int pop(STACK *ps)
{
	return(ps->data[ps->top--]);
}
int isempty(STACK *ps)
{
	return(ps->top == -1);
}
int isfull(STACK *ps)
{
	return(ps->top==MAX-1);
}
void evaluate(char post[])
{
	int value,i, opnd1,opnd2;
	STACK s1;
 	initstack(&s1);
  	for(i=0; post[i]!='\0';i++)
  	{
		if(isalpha(post[i])) //operand
     		{
        		printf("\nEnter the value of %c :", post[i]);
  			scanf("%d",&value);
  			push(&s1, value);     
		}
	 	else
    		{
       			opnd2=pop(&s1);
 		  	opnd1=pop(&s1);
     			switch(post[i])
     			{
     				case '+' : 
					push(&s1, opnd1 + opnd2); 
				break;
       				case '-' : 
					push(&s1, opnd1 - opnd2); 
				break;
       				case '*' : 
					push(&s1, opnd1 * opnd2); 
				break;
   	    			case '/' : 
					push(&s1, opnd1 / opnd2); 
				break;
     		  		case '%' : 
					push(&s1, opnd1 % opnd2); 
				break;
     			}
    		}//end else
  	}//end for
  printf("\n The result is : %d", pop(&s1));
}

int main()
{
	char  post[20];
	printf("\n Enter the postfix expression :");
	scanf("%s",post);
	evaluate(post);
}



