// Program 5.2 : Dynamic Implementation of Stack 

#include <stdio.h>
#include <malloc.h>

typedef struct node
{
 	int info;
 	struct node *next;
}NODE;

NODE * top;

void initstack()
{ 
	top= NULL;  
}

int isempty()
{ 
	return (top == NULL); 
}
void push(int  num)
{
	NODE * newnode = (NODE *)malloc(sizeof(NODE));
	newnode->info = num;
	newnode->next=NULL;
	newnode->next=top;
	top=newnode;
}

int pop()
{
 	int num;
	NODE * temp = top;
	num = top->info;
	top = top->next;
	free(temp);
	return num;
}

int main()
{
 	int choice, n;
  	initstack();
 	do  	
	{
  		printf("\n1:PUSH\n2:POP\n3:EXIT\n");
  		printf("Enter your choice :");
		scanf("%d",&choice);
  		switch(choice)
  		{
   			case 1 : /* PUSH */
				printf("\n enter the element to be pushed :");
				scanf("%d",&n);
				push(n);
				break;
  		 	case 2 :/* POP */
				if(isempty())
	  				printf("\nStack is empty ");
	 			else
	  				printf("\n Popped element : %d", pop());
			break;
  		}
	}while(choice!=3);
}


