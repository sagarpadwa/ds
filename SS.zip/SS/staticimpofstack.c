// Program 5.1 : Static implementation of stack

#include <stdio.h>
#define MAX 20
typedef struct 
{ 
	int data[MAX];
	int  top;
}STACK;

void initstack(STACK *ps)
{ 	
	ps->top = -1;
}

void push(STACK *ps, int num)
{
  	ps->top++;
  	ps->data[ps->top] = num;
  	
}
int pop(STACK *ps)
{
	return(ps->data[ps->top--]);
}
int isempty(STACK *ps)
{
	return(ps->top == -1);
}
int isfull(STACK *ps)
{
	return(ps->top==MAX-1);
}

int main()
{ 	
  int n,choice;
  STACK  s1;
  initstack(&s1);
  
  do
  {
   	printf("\n1:PUSH\n2:POP\n3:EXIT");
   	printf("\n\nEnter your choice :");
   	scanf("%d",&choice);
   	switch(choice)
   	{
    		case 1 : /* PUSH */
			if (isfull(&s1))
				printf("\n Stack Overflow");
			else
			{
				printf("Enter the element to be pushed");
				scanf("%d",&n);
				push(&s1, n);
			}

		break;
    		case 2 : /* POP */
			if(isempty(&s1)==1)
				printf("\nStack underflow \n");
			else
		  		printf("The popped element is : %d",pop(&s1));
		 break;
    	}
  } 	
	while(choice !=3);
}



