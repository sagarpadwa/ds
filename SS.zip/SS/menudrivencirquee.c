#include <stdio.h>
#include <stdlib.h>

// Node structure for the circular linked list
struct Node {
    int data;
    struct Node* next;
};

// Circular Queue structure
struct CircularQueue {
    struct Node* rear;
};

// Function to initialize the circular queue
void init(struct CircularQueue* Q) {
    Q->rear = NULL;
}

// Function to add an element to the circular queue
void AddQueue(struct CircularQueue* Q, int value) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Memory allocation error\n");
        exit(EXIT_FAILURE);
    }

    newNode->data = value;

    if (Q->rear == NULL) {
        // If the queue is empty
        newNode->next = newNode;
        Q->rear = newNode;
    } else {
        // If the queue is not empty
        newNode->next = Q->rear->next;
        Q->rear->next = newNode;
        Q->rear = newNode;
    }
}

// Function to delete an element from the circular queue
int DeleteQueue(struct CircularQueue* Q) {
    if (Q->rear == NULL) {
        printf("Queue is empty\n");
        exit(EXIT_FAILURE);
    }

    int deletedValue;
    struct Node* front = Q->rear->next;

    if (Q->rear == front) {
        // If there is only one element in the queue
        deletedValue = front->data;
        free(front);
        Q->rear = NULL;
    } else {
        // If there are more than one elements in the queue
        Q->rear->next = front->next;
        deletedValue = front->data;
        free(front);
    }

    return deletedValue;
}

// Function to display the elements of the circular queue
void displayQueue(struct CircularQueue* Q) {
    if (Q->rear == NULL) {
        printf("Queue is empty\n");
        return;
    }

    struct Node* front = Q->rear->next;
    struct Node* current = front;

    do {
        printf("%d ", current->data);
        current = current->next;
    } while (current != front);

    printf("\n");
}

// Function to clear the circular queue (free memory)
void clearQueue(struct CircularQueue* Q) {
    while (Q->rear != NULL) {
        DeleteQueue(Q);
    }
}

// Menu-driven program to interact with circular queue operations
int main() {
    struct CircularQueue myQueue;
    init(&myQueue);

    int choice, value;

    do {
        printf("\nCircular Queue Menu:\n");
        printf("1. Add element to the queue\n");
        printf("2. Delete element from the queue\n");
        printf("3. Display queue\n");
        printf("4. Clear queue\n");
        printf("0. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter the value to add to the queue: ");
                scanf("%d", &value);
                AddQueue(&myQueue, value);
                break;
            case 2:
                if (myQueue.rear == NULL) {
                    printf("Queue is empty. Cannot delete.\n");
                } else {
                    printf("Deleted element: %d\n", DeleteQueue(&myQueue));
                }
                break;
            case 3:
                printf("Current queue: ");
                displayQueue(&myQueue);
                break;
            case 4:
                clearQueue(&myQueue);
                printf("Queue cleared.\n");
                break;
            case 0:
                printf("Exiting program.\n");
                break;
            default:
                printf("Invalid choice. Please enter a valid option.\n");
        }

    } while (choice != 0);

    return 0;
}
