#include <stdio.h>
#include <stdlib.h>

// Node structure for singly linked list
struct Node {
    int data;
    struct Node* next;
};

// List structure
struct List {
    struct Node* head;
};

// Function to initialize the list
void initList(struct List* list) {
    list->head = NULL;
}

// Function to add a new node to the list
void addNode(struct List* list, int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Memory allocation error\n");
        exit(EXIT_FAILURE);
    }

    newNode->data = data;
    newNode->next = NULL;

    if (list->head == NULL) {
        list->head = newNode;
    } else {
        struct Node* current = list->head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = newNode;
    }
}

// Function to reverse the list
void reverseList(struct List* list) {
    struct Node *prev, *current, *next;
    prev = NULL;
    current = list->head;

    while (current != NULL) {
        next = current->next;
        current->next = prev;
        prev = current;
        current = next;
    }

    list->head = prev;
}

// Function to display the list
void displayList(struct List* list) {
    struct Node* current = list->head;
    while (current != NULL) {
        printf("%d ", current->data);
        current = current->next;
    }
    printf("\n");
}

int main() {
    struct List myList;
    initList(&myList);

    // Add elements to the list
    addNode(&myList, 1);
    addNode(&myList, 2);
    addNode(&myList, 3);
    addNode(&myList, 4);
    addNode(&myList, 5);

    printf("Original List: ");
    displayList(&myList);

    // Reverse the list
    reverseList(&myList);

    printf("Reversed List: ");
    displayList(&myList);

    return 0;
}
