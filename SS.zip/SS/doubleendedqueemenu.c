#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 5

struct Deque {
    int items[MAX_SIZE];
    int front, rear;
};

void initDeque(struct Deque* deque) {
    deque->front = -1;
    deque->rear = -1;
}

int isFull(struct Deque* deque) {
    return ((deque->front == 0 && deque->rear == MAX_SIZE - 1) || (deque->rear == (deque->front - 1) % (MAX_SIZE - 1)));
}

void addFront(struct Deque* deque, int value) {
    if (isFull(deque)) {
        printf("Deque is full. Cannot add to the front.\n");
        exit(EXIT_FAILURE);
    }

    if (deque->front == -1) {
        deque->front = 0;
        deque->rear = 0;
    } else if (deque->front == 0) {
        deque->front = MAX_SIZE - 1;
    } else {
        deque->front = (deque->front - 1) % (MAX_SIZE - 1);
    }

    deque->items[deque->front] = value;
}

int getRear(struct Deque* deque) {
    if (deque->rear == -1) {
        printf("Deque is empty.\n");
        exit(EXIT_FAILURE);
    }

    return deque->items[deque->rear];
}

int deleteRear(struct Deque* deque) {
    if (deque->rear == -1) {
        printf("Deque is empty. Cannot delete from the rear.\n");
        exit(EXIT_FAILURE);
    }

    int deletedValue = deque->items[deque->rear];

    if (deque->front == deque->rear) {
        // If there is only one element in the deque
        deque->front = -1;
        deque->rear = -1;
    } else if (deque->rear == 0) {
        deque->rear = MAX_SIZE - 1;
    } else {
        deque->rear = (deque->rear - 1) % (MAX_SIZE - 1);
    }

    return deletedValue;
}

int main() {
    struct Deque myDeque;
    initDeque(&myDeque);

    int choice, value;

    do {
        printf("\nDeque Menu:\n");
        printf("1. isFull\n");
        printf("2. Add element to the front\n");
        printf("3. Get rear element\n");
        printf("4. Delete rear element\n");
        printf("0. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                if (isFull(&myDeque)) {
                    printf("Deque is full.\n");
                } else {
                    printf("Deque is not full.\n");
                }
                break;
            case 2:
                printf("Enter the value to add to the front: ");
                scanf("%d", &value);
                addFront(&myDeque, value);
                break;
            case 3:
                if (myDeque.rear == -1) {
                    printf("Deque is empty. Cannot get rear element.\n");
                } else {
                    printf("Rear element: %d\n", getRear(&myDeque));
                }
                break;
            case 4:
                if (myDeque.rear == -1) {
                    printf("Deque is empty. Cannot delete from the rear.\n");
                } else {
                    printf("Deleted rear element: %d\n", deleteRear(&myDeque));
                }
                break;
            case 0:
                printf("Exiting program.\n");
                break;
            default:
                printf("Invalid choice. Please enter a valid option.\n");
        }

    } while (choice != 0);

    return 0;
}
