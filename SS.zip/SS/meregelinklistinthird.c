#include <stdio.h>
#include <stdlib.h>

// Node structure for a linked list
struct Node {
    int data;
    struct Node* next;
};

// Function to insert a node at the end of a linked list
void insertEnd(struct Node** head, int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        printf("Memory allocation error\n");
        exit(EXIT_FAILURE);
    }

    newNode->data = data;
    newNode->next = NULL;

    if (*head == NULL) {
        *head = newNode;
    } else {
        struct Node* current = *head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = newNode;
    }
}

// Function to merge two ordered linked lists into a new ordered list
struct Node* mergeOrderedLists(struct Node* list1, struct Node* list2) {
    struct Node* mergedList = NULL;

    while (list1 != NULL && list2 != NULL) {
        if (list1->data < list2->data) {
            insertEnd(&mergedList, list1->data);
            list1 = list1->next;
        } else {
            insertEnd(&mergedList, list2->data);
            list2 = list2->next;
        }
    }

    // Add remaining elements from list1
    while (list1 != NULL) {
        insertEnd(&mergedList, list1->data);
        list1 = list1->next;
    }

    // Add remaining elements from list2
    while (list2 != NULL) {
        insertEnd(&mergedList, list2->data);
        list2 = list2->next;
    }

    return mergedList;
}

// Function to display a linked list
void displayList(struct Node* head) {
    struct Node* current = head;

    while (current != NULL) {
        printf("%d ", current->data);
        current = current->next;
    }

    printf("\n");
}

int main() {
    struct Node* list1 = NULL;
    struct Node* list2 = NULL;

    // Insert elements into the first ordered list
    insertEnd(&list1, 1);
    insertEnd(&list1, 3);
    insertEnd(&list1, 5);

    // Insert elements into the second ordered list
    insertEnd(&list2, 2);
    insertEnd(&list2, 4);
    insertEnd(&list2, 6);

    printf("List 1: ");
    displayList(list1);

    printf("List 2: ");
    displayList(list2);

    // Merge the two ordered lists into a new ordered list
    struct Node* mergedList = mergeOrderedLists(list1, list2);

    printf("Merged List: ");
    displayList(mergedList);

    return 0;
}
