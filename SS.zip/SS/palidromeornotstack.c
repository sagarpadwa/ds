#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_SIZE 100

struct CharStack {
    char items[MAX_SIZE];
    int top;
};

void initCharStack(struct CharStack* stack) {
    stack->top = -1;
}

int isCharStackEmpty(struct CharStack* stack) {
    return stack->top == -1;
}

int isCharStackFull(struct CharStack* stack) {
    return stack->top == MAX_SIZE - 1;
}

void pushChar(struct CharStack* stack, char value) {
    if (isCharStackFull(stack)) {
        printf("CharStack overflow\n");
        exit(EXIT_FAILURE);
    }

    stack->items[++stack->top] = value;
}

char popChar(struct CharStack* stack) {
    if (isCharStackEmpty(stack)) {
        printf("CharStack underflow\n");
        exit(EXIT_FAILURE);
    }

    return stack->items[stack->top--];
}

int isPalindrome(const char* str) {
    struct CharStack charStack;
    initCharStack(&charStack);

    int len = strlen(str);

    for (int i = 0; i < len / 2; ++i) {
        pushChar(&charStack, str[i]);
    }

    // Check if the string is a palindrome
    int j = len / 2 + (len % 2);  // Skip the middle character for odd-length strings
    while (j < len) {
        char topChar = popChar(&charStack);
        if (topChar != str[j]) {
            return 0;  // Not a palindrome
        }
        ++j;
    }

    return 1;  // Palindrome
}

int main() {
    char str[MAX_SIZE];

    printf("Enter a string: ");
    scanf("%s", str);

    if (isPalindrome(str)) {
        printf("The string is a palindrome.\n");
    } else {
        printf("The string is not a palindrome.\n");
    }

    return 0;
}
