// Program 4.4 : Merging of two linked lists

#include<stdio.h>
#include<malloc.h>

typedef struct node
{
 	int info;
 	struct node *next;
}NODE;

NODE * createlist(NODE * list)
{
 	int n,i;
	NODE * temp, *newnode;
 	printf("\n\nHow many elements in the list :");
 	scanf("%d",&n);
 	printf("\nEnter the %d elements :\n", n);
 	temp=list;
 	for(i=1;i<=n;i++)
 	{
  		newnode=(NODE *)malloc(sizeof(struct node));
  		newnode->next=NULL;
  		scanf("%d",&newnode->info);
	  if(list==NULL)
   		list=temp=newnode;
  		else
  		{
  			temp->next=newnode;
  			temp=newnode;	
		}
	}
 	return list;  
}
void display(NODE * list)
{
 	NODE * temp=list;
	for(temp=list;temp!=NULL; temp=temp->next)
  		printf("%d\t", temp->info); 
}
NODE * merge(NODE * list1, NODE * list2, NODE * list3)
{
 	NODE * t1=list1,* t2=list2,* t3=list3,* newnode;
	while(t1 && t2)
 	{
  		newnode=(NODE *)malloc(sizeof(struct node));
  		newnode->next=NULL;
  		if(t1->info < t2->info)
  		{
     			newnode->info=t1->info;
       			t1=t1->next; 		
		}
  		else
  		{
      			newnode->info=t2->info;
      			t2=t2->next;  		}
  		/** attach newnode **/
  		if(list3==NULL)
  			t3=list3=newnode;
  		else
  		{
   		t3->next=newnode;
   		t3=t3->next;
  		}
	}   /** end while **/
	if(t1) /**  first list has not ended **/
		t3->next=t1;
	if(t2)       /* second list has not ended */
		t3->next=t2;
	return list3;
}

int main()
{
 	NODE * list1=NULL, *list2=NULL, *list3=NULL;
 	list1=createlist(list1);
 	list2=createlist(list2);
 	list3=merge(list1, list2, list3);
 	printf("\nThe first list is \n");
 	display(list1);
 	printf("\nThe second list is \n");
	 	display(list2);
 	printf("\nThe merged list is :");
 	display(list3);
}



