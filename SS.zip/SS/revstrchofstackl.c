#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Stack structure
#define MAX_SIZE 100

struct Stack {
    char items[MAX_SIZE];
    int top;
};

// Function to initialize the stack
void initStack(struct Stack* stack) {
    stack->top = -1;
}

// Function to check if the stack is empty
int isEmpty(struct Stack* stack) {
    return stack->top == -1;
}

// Function to check if the stack is full
int isFull(struct Stack* stack) {
    return stack->top == MAX_SIZE - 1;
}

// Function to push a character onto the stack
void push(struct Stack* stack, char value) {
    if (isFull(stack)) {
        printf("Stack overflow\n");
        exit(EXIT_FAILURE);
    }

    stack->items[++stack->top] = value;
}

// Function to pop a character from the stack
char pop(struct Stack* stack) {
    if (isEmpty(stack)) {
        printf("Stack underflow\n");
        exit(EXIT_FAILURE);
    }

    return stack->items[stack->top--];
}

int main() {
    struct Stack charStack;
    initStack(&charStack);

    char inputString[100];

    printf("Enter a string: ");
    fgets(inputString, sizeof(inputString), stdin);
    inputString[strcspn(inputString, "\n")] = '\0'; // Remove newline character if present

    // Push characters onto the stack
    for (int i = 0; i < strlen(inputString); ++i) {
        push(&charStack, inputString[i]);
    }

    // Pop characters from the stack to reverse the string
    printf("Reversed String: ");
    while (!isEmpty(&charStack)) {
        printf("%c", pop(&charStack));
    }
    printf("\n");

    return 0;
}
