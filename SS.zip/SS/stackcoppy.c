#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 100

struct Stack {
    int items[MAX_SIZE];
    int top;
};

void initializeStack(struct Stack* stack) {
    stack->top = -1;
}

int isEmpty(struct Stack* stack) {
    return stack->top == -1;
}

int isFull(struct Stack* stack) {
    return stack->top == MAX_SIZE - 1;
}

void push(struct Stack* stack, int value) {
    if (isFull(stack)) {
        printf("Stack overflow\n");
        return;
    }
    stack->items[++stack->top] = value;
}

int pop(struct Stack* stack) {
    if (isEmpty(stack)) {
        printf("Stack underflow\n");
        exit(EXIT_FAILURE);
    }
    return stack->items[stack->top--];
}

void copyStack(struct Stack* source, struct Stack* destination) {
    struct Stack tempStack;
    initializeStack(&tempStack);

    while (!isEmpty(source)) {
        push(&tempStack, pop(source));
    }

    while (!isEmpty(&tempStack)) {
        int value = pop(&tempStack);
        push(destination, value);
        push(source, value);
    }
}

void printStack(struct Stack* stack) {
    printf("Stack: ");
    for (int i = 0; i <= stack->top; ++i) {
        printf("%d ", stack->items[i]);
    }
    printf("\n");
}

int main() {
    struct Stack stack1, stack2;
    initializeStack(&stack1);
    initializeStack(&stack2);

    push(&stack1, 1);
    push(&stack1, 2);
    push(&stack1, 3);
    push(&stack1, 4);

    copyStack(&stack1, &stack2);

    printf("Original ");
    printStack(&stack1);

    printf("Copied   ");
    printStack(&stack2);

    return 0;
}
