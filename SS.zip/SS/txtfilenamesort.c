#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Employee {
    char name[50];
    int age;
    double salary;
};

void readDataFromFile(struct Employee employees[], int *size) {
    FILE *file = fopen("employee.txt", "r");
    if (file == NULL) {
        perror("Error opening file");
        exit(EXIT_FAILURE);
    }

    *size = 0;
    while (fscanf(file, "%s %d %lf", employees[*size].name, &employees[*size].age, &employees[*size].salary) == 3) {
        (*size)++;
    }

    fclose(file);
}

void selectionSort(struct Employee employees[], int size) {
    int i, j, minIndex;
    struct Employee temp;

    for (i = 0; i < size - 1; i++) {
        minIndex = i;
        for (j = i + 1; j < size; j++) {
            if (strcmp(employees[j].name, employees[minIndex].name) < 0) {
                minIndex = j;
            }
        }

        temp = employees[minIndex];
        employees[minIndex] = employees[i];
        employees[i] = temp;
    }
}

void printSortedData(struct Employee employees[], int size) {
    printf("Sorted Data (Selection Sort):\n");
    for (int i = 0; i < size; i++) {
        printf("%s %d %.2lf\n", employees[i].name, employees[i].age, employees[i].salary);
    }
}

int main() {
    struct Employee employees[100];
    int size;

    readDataFromFile(employees, &size);

    selectionSort(employees, size);

    printSortedData(employees, size);

    return 0;
}
