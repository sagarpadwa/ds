#include <stdio.h>
#include <stdlib.h>

// Node structure for a term in a polynomial
struct Term {
    int coefficient;
    int exponent;
    struct Term* next;
};

// Polynomial structure
struct Polynomial {
    struct Term* head;
};

// Function to initialize a polynomial
void initPolynomial(struct Polynomial* poly) {
    poly->head = NULL;
}

// Function to add a term to a polynomial
void addTerm(struct Polynomial* poly, int coefficient, int exponent) {
    struct Term* newTerm = (struct Term*)malloc(sizeof(struct Term));
    if (newTerm == NULL) {
        printf("Memory allocation error\n");
        exit(EXIT_FAILURE);
    }

    newTerm->coefficient = coefficient;
    newTerm->exponent = exponent;
    newTerm->next = NULL;

    if (poly->head == NULL) {
        poly->head = newTerm;
    } else {
        struct Term* current = poly->head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = newTerm;
    }
}

// Function to add two polynomials
struct Polynomial addPolynomials(struct Polynomial poly1, struct Polynomial poly2) {
    struct Polynomial result;
    initPolynomial(&result);

    struct Term *term1 = poly1.head, *term2 = poly2.head;

    while (term1 != NULL && term2 != NULL) {
        if (term1->exponent > term2->exponent) {
            addTerm(&result, term1->coefficient, term1->exponent);
            term1 = term1->next;
        } else if (term1->exponent < term2->exponent) {
            addTerm(&result, term2->coefficient, term2->exponent);
            term2 = term2->next;
        } else {
            // Add coefficients when exponents are equal
            addTerm(&result, term1->coefficient + term2->coefficient, term1->exponent);
            term1 = term1->next;
            term2 = term2->next;
        }
    }

    // Add remaining terms from poly1
    while (term1 != NULL) {
        addTerm(&result, term1->coefficient, term1->exponent);
        term1 = term1->next;
    }

    // Add remaining terms from poly2
    while (term2 != NULL) {
        addTerm(&result, term2->coefficient, term2->exponent);
        term2 = term2->next;
    }

    return result;
}

// Function to display a polynomial
void displayPolynomial(struct Polynomial poly) {
    struct Term* current = poly.head;

    while (current != NULL) {
        printf("%dx^%d ", current->coefficient, current->exponent);
        if (current->next != NULL) {
            printf("+ ");
        }
        current = current->next;
    }

    printf("\n");
}

int main() {
    struct Polynomial poly1, poly2, result;
    initPolynomial(&poly1);
    initPolynomial(&poly2);
    initPolynomial(&result);

    // Adding terms to the first polynomial
    addTerm(&poly1, 3, 4);
    addTerm(&poly1, 2, 2);
    addTerm(&poly1, 1, 1);

    // Adding terms to the second polynomial
    addTerm(&poly2, 4, 3);
    addTerm(&poly2, 1, 1);
    addTerm(&poly2, 5, 0);

    // Displaying the first polynomial
    printf("Polynomial 1: ");
    displayPolynomial(poly1);

    // Displaying the second polynomial
    printf("Polynomial 2: ");
    displayPolynomial(poly2);

    // Adding the polynomials and displaying the result
    result = addPolynomials(poly1, poly2);
    printf("Sum of Polynomials: ");
    displayPolynomial(result);

    return 0;
}
