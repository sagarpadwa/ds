#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 100

struct Stack {
    int items[MAX_SIZE];
    int top;
};

void initStack(struct Stack* stack) {
    stack->top = -1;
}

int isStackEmpty(struct Stack* stack) {
    return stack->top == -1;
}

int isStackFull(struct Stack* stack) {
    return stack->top == MAX_SIZE - 1;
}

void push(struct Stack* stack, int value) {
    if (isStackFull(stack)) {
        printf("Stack overflow\n");
        exit(EXIT_FAILURE);
    }

    stack->items[++stack->top] = value;
}

int pop(struct Stack* stack) {
    if (isStackEmpty(stack)) {
        printf("Stack underflow\n");
        exit(EXIT_FAILURE);
    }

    return stack->items[stack->top--];
}

int peek(struct Stack* stack) {
    if (isStackEmpty(stack)) {
        printf("Stack underflow\n");
        exit(EXIT_FAILURE);
    }

    return stack->items[stack->top];
}

int areStacksIdentical(const struct Stack* stack1, const struct Stack* stack2) {
    if (stack1->top != stack2->top) {
        return 0; // Stacks have different sizes
    }

    for (int i = 0; i <= stack1->top; ++i) {
        if (stack1->items[i] != stack2->items[i]) {
            return 0; // Stacks have different elements
        }
    }

    return 1; // Stacks are identical
}

int main() {
    struct Stack stack1, stack2;
    initStack(&stack1);
    initStack(&stack2);

    // Push some elements onto both stacks
    push(&stack1, 1);
    push(&stack1, 2);
    push(&stack1, 3);

    push(&stack2, 1);
    push(&stack2, 2);
    push(&stack2, 3);

    // Check if the contents of both stacks are identical
    if (areStacksIdentical(&stack1, &stack2)) {
        printf("The contents of both stacks are identical.\n");
    } else {
        printf("The contents of both stacks are not identical.\n");
    }

    return 0;
}
