// Program 5.4 : Infix to Postfix using Priority Method 

#include <stdio.h>
#define MAX 20

typedef struct 
{ 
	int data[MAX];
	int  top;
}STACK;

void initstack(STACK *ps)
{ 	
	ps->top = -1;
}

void push(STACK *ps, int num)
{
  	ps->top++;
  	ps->data[ps->top] = num;
  	
}
int pop(STACK *ps)
{
	return(ps->data[ps->top--]);
}
int isempty(STACK *ps)
{
	return(ps->top == -1);
}
int isfull(STACK *ps)
{
	return(ps->top==MAX-1);
}
int stacktop(STACK *ps)
{  
	return ps->data[ps->top]; 
}
int priority(char ch)
{
	switch(ch)
  	{
  		case '(' : return 0;
    		case '+':
    		case '-': return 1;
    		case '*' :
    		case '/' :
	  	case '%': return 2;
  	}
  	return 0;
}
void postfix(char *in, char *post)
{
  int i,j=0;
  char ch;
  STACK s1;
  initstack(&s1);
  for(i=0; in[i]!='\0';i++)
  {
    	switch (in[i])
    	{
    		case '(': push(&s1,in[i]);
			break;
		case '+':
      		case '-' :
      		case '*':
      		case '/' :
      		case '%' :
			if( isempty(&s1))
				push(&s1,in[i]);
			else
			{
     				while( priority(in[i])<=priority(stacktop(&s1))	)
 	 	 	      	post[j++]=pop(&s1);
		 		push(&s1, in[i]);
			}
			break;
		case ')' :
			while((ch = pop(&s1))!='(')
			   post[j++]=ch;
       		break;
		default: //operand
           		post[j++]=in[i];
    	}/* end switch */
  }/* end of for */
  while(!isempty(&s1))
  	post[j++]=pop(&s1);
	post[j]='\0';
}
int main()
{
 	char in[20], post[20];

 	printf("\nEnter the infix expression :");
 	scanf("%s",in);
 	postfix(in,post);
	printf("The postfix string is : %s", post);
}



