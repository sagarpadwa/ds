// PriorityQ.h

#ifndef PRIORITYQ_H
#define PRIORITYQ_H

#define MAX_SIZE 100

struct PriorityQ {
    int elements[MAX_SIZE];
    int priorities[MAX_SIZE];
    int front, rear;
};

// Function to initialize the priority queue
void initPriorityQ(struct PriorityQ* priorityQ);

// Function to check if the priority queue is empty
int isPriorityQEmpty(struct PriorityQ* priorityQ);

// Function to check if the priority queue is full
int isPriorityQFull(struct PriorityQ* priorityQ);

// Function to add an element with its priority to the priority queue
void enqueueWithPriority(struct PriorityQ* priorityQ, int element, int priority);

// Function to delete an element from the priority queue based on its priority
int dequeueWithPriority(struct PriorityQ* priorityQ);

#endif // PRIORITYQ_H

// PriorityQ.c

#include "PriorityQ.h"
#include <stdio.h>
#include <stdlib.h>

void initPriorityQ(struct PriorityQ* priorityQ) {
    priorityQ->front = -1;
    priorityQ->rear = -1;
}

int isPriorityQEmpty(struct PriorityQ* priorityQ) {
    return (priorityQ->front == -1) || (priorityQ->front > priorityQ->rear);
}

int isPriorityQFull(struct PriorityQ* priorityQ) {
    return priorityQ->rear == MAX_SIZE - 1;
}

void enqueueWithPriority(struct PriorityQ* priorityQ, int element, int priority) {
    if (isPriorityQFull(priorityQ)) {
        printf("Priority Queue overflow\n");
        exit(EXIT_FAILURE);
    }

    if (isPriorityQEmpty(priorityQ)) {
        priorityQ->front = 0;
        priorityQ->rear = 0;
    } else {
        priorityQ->rear++;
    }

    priorityQ->elements[priorityQ->rear] = element;
    priorityQ->priorities[priorityQ->rear] = priority;
}

int dequeueWithPriority(struct PriorityQ* priorityQ) {
    if (isPriorityQEmpty(priorityQ)) {
        printf("Priority Queue underflow\n");
        exit(EXIT_FAILURE);
    }

    int minPriorityIndex = priorityQ->front;
    int minPriority = priorityQ->priorities[priorityQ->front];

    for (int i = priorityQ->front + 1; i <= priorityQ->rear; ++i) {
        if (priorityQ->priorities[i] < minPriority) {
            minPriorityIndex = i;
            minPriority = priorityQ->priorities[i];
        }
    }

    int dequeuedElement = priorityQ->elements[minPriorityIndex];

    // Move elements to fill the gap
    for (int i = minPriorityIndex; i < priorityQ->rear; ++i) {
        priorityQ->elements[i] = priorityQ->elements[i + 1];
        priorityQ->priorities[i] = priorityQ->priorities[i + 1];
    }

    priorityQ->rear--;

    return dequeuedElement;
}

// Main program

#include <stdio.h>

int main() {
    struct PriorityQ myPriorityQ;
    initPriorityQ(&myPriorityQ);

    enqueueWithPriority(&myPriorityQ, 1, 3);
    enqueueWithPriority(&myPriorityQ, 2, 1);
    enqueueWithPriority(&myPriorityQ, 3, 2);

    printf("Dequeued element with priority: %d\n", dequeueWithPriority(&myPriorityQ));

    return 0;
}
